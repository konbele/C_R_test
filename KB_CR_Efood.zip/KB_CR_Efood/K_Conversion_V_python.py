# Import Libraries


import pandas as pd
from datetime import datetime
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.formula.api import ols

### SQL Queries

"""  Query for conversion rate (suggested_shop.clicked) by variation 
with clic_k as (
                select p.date, p.variation_name ,count( distinct p.session_id) as Clicked_sessions 

                from product-analytics-test.pa_dataset.experiment_data_10395400658 as p
                where p.event_key = 'suggested_shop.clicked'
                AND p.events > 0
                group by 1,2
                order by 1 asc ,2

                ) ,
tota_l as       (
                select p.date, p.variation_name,count( distinct p.session_id) as Total_sessions 

                from product-analytics-test.pa_dataset.experiment_data_10395400658 as p
                group by 1,2
                order by 1 asc ,2

                )

select t.date , t.variation_name , t.Total_sessions , c.Clicked_sessions  , c.Clicked_sessions / t.Total_sessions  as rate
from tota_l t  
inner join clic_k c on t.variation_name = c.variation_name  and t.date = c.date 
order by t.date
"""

"""  Query for conversion rate (suggested_shop.clicked) by variation and visit type 
with clic_k as (
                select p.date, p.variation_name,p.visitType ,count( distinct p.session_id) as Clicked_sessions 
                
                from product-analytics-test.pa_dataset.experiment_data_10395400658 as p
                where p.event_key = 'suggested_shop.clicked'
                AND p.events > 0
                group by 1,2,3
                order by 1 asc ,2

                ) ,
tota_l as       (
                select p.date, p.variation_name,p.visitType ,count( distinct p.session_id) as Total_sessions 
                
                from product-analytics-test.pa_dataset.experiment_data_10395400658 as p
                group by 1,2,3
                order by 1 asc ,2

                )

select t.date ,t.visitType, t.variation_name , t.Total_sessions , c.Clicked_sessions  , c.Clicked_sessions / t.Total_sessions  as rate
from tota_l t  
inner join clic_k c on t.variation_name = c.variation_name  and t.date = c.date and t.visitType=c.visitType
order by t.date
"""

# Exam the difference between the variation conversion rates


data = pd.read_csv('Rate_Variation.csv')
data.sort_values(by=['date'])

#Density plot
sns.distplot(data['rate'][data['variation_name']=='Original'])
sns.distplot(data['rate'][data['variation_name']=='Variation #1'])
sns.distplot(data['rate'][data['variation_name']=='Variation #2'])

#Timeseries
sns.lineplot(x = data['date'][data['variation_name']=='Original'], y = data['rate'][data['variation_name']=='Original'], data = data)
sns.lineplot(x = data['date'][data['variation_name']=='Variation #1'], y = data['rate'][data['variation_name']=='Variation #1'], data = data)
sns.lineplot(x = data['date'][data['variation_name']=='Variation #2'], y = data['rate'][data['variation_name']=='Variation #2'], data = data)



# We need to clean some outliers that we have seen in the above plots on the first date
# and take care date values with no data of all the variations
s=data.groupby(['date'])['rate'].count()
print(s[s != 3])

print(data[data['rate']==1])

data = data[data['rate'] != 1]

# ANOVA part -   test if the rates between the variation  are statistically significant differnet

# A one-way ANOVA uses the following null and alternative hypotheses:
#
# H0 (null hypothesis): μ1 = μ2 = μ3  (all the population means are equal)
# H1 (null hypothesis): at least one population mean is different from the rest


#perform one-way ANOVA
model = ols('rate ~ C(variation_name) ', data=data).fit()
sm.stats.anova_lm(model, typ=1)



# The F test statistic is  9.328937 and the corresponding p-value is 0.000194. Since the p-value is  less than 0.05,
# we   reject the null hypothesis. This means we do have sufficient evidence to say that there is a difference
# in the conversion rate among the three variations-experiments.

######################################################################################################

# Exam the difference between the variation conversion rates


data = pd.read_csv('Rate_Variation_Visit.csv')
data.sort_values(by=['date'])

#Density plot
sns.distplot(data['rate'][data['variation_name']=='Original'])
sns.distplot(data['rate'][data['variation_name']=='Variation #1'])
sns.distplot(data['rate'][data['variation_name']=='Variation #2'])

#Timeseries
sns.lineplot(x = data['date'][data['variation_name']=='Original'], y = data['rate'][data['variation_name']=='Original'], data = data)
sns.lineplot(x = data['date'][data['variation_name']=='Variation #1'], y = data['rate'][data['variation_name']=='Variation #1'], data = data)
sns.lineplot(x = data['date'][data['variation_name']=='Variation #2'], y = data['rate'][data['variation_name']=='Variation #2'], data = data)



# We need to clean some outliers that we have seen in the above plots on the first date
# and take care date values with no data of all the variations
s=data.groupby(['date'])['rate'].count()
print(s[s != 6])

print(data[data['rate']==1])

data = data[data['rate'] != 1]
data = data.pivot_table(
            values=['rate'],
            index=['date','visitType'],
            columns='variation_name',
            aggfunc={ 'rate':sum},fill_value=0).sort_values(by=['date'],ascending=True).reset_index().droplevel(0,1)

data.columns=['date', 'visitType', 'Original', 'Variation #1', 'Variation #2']

data = data.melt(id_vars=['date','visitType'], var_name='variation_name', value_name='rate')
data = data.sort_values(by=['date'])

# ANOVA part -   test if the rates between the variation  are statistically significant differnet

# A two-way ANOVA uses the following null and alternative hypotheses:
#
# H0 (null hypothesis): μ1 = μ2 = μ3  (all the population means are equal)
# H1 (null hypothesis): at least one population mean is different from the rest


#perform two-way ANOVA
model = ols('rate ~ C(variation_name) + C(visitType) + C(variation_name):C(visitType)', data=data).fit()
sm.stats.anova_lm(model, typ=2)



# Since the p-values for variation_name is less than 0.05,
# this means that this factor has a statistically significant effect on conversion rate.
# Since the p-values for visitType is not less than 0.05,
# this means that this factor has not a statistically significant effect on conversion rate.
#
# And since the p-value for the interaction effect (0.133015) is not less than .05,
# this tells us that there is no significant interaction effect between variation_name  and visitType.





